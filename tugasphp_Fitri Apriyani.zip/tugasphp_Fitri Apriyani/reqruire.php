<?php

//Fungsi require() yaitu untuk menyisipkan file php yang lain dari file php utama.

require('fungsi.php');

?>