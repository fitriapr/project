<?php

//Fungsi include() yaitu untuk menyisipkan file php yang lain dari file php utama.

include('fungsi.php');

?>
