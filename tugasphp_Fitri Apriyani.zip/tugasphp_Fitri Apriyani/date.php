<?php
//fungsi date() yaitu untuk mendefinisikan tangaal bulan dan tahun.
echo "sekarang tanggal:".date("d-M-Y"). "</br>";
?>