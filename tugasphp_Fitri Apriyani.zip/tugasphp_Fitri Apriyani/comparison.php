<?php

$F = 10;
$A = 15;

echo " 10 equal 15 = ";
var_dump($F == $A);

echo " 10 not equal 15 = ";
var_dump($F != $A);

echo " 10 greater than 15 = ";
var_dump($F > $A);

echo " 10 less than 15 = ";
var_dump($F < $A);

echo " 10 greater than or equal 15 = ";
var_dump($F >= $A);

echo " 10 less than or equal 15 = ";
var_dump($F <= $A);

?>