<?php

$F = 100;
$A = 70;

echo "100 + 70 = ";
echo  $F + $A . "</br>";

echo "100 - 70 = ";
echo  $F - $A . "</br>";

echo "100 * 70 = ";
echo  $F * $A . "</br>";

echo "100 / 70 = ";
echo  $F / $A . "</br>";

echo "100 % 70 = ";
echo  $F % $A . "</br>";

echo "100 + 70 = ";
echo  $F++. "</br>";

echo "100 -- 70 = ";
echo  $F--. "</br>";

?>