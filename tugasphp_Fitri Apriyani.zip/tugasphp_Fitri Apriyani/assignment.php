<?php

$r = 10;
    $s = 10;
    $t = 10;
    $u = 10;
    $v = 70;

    $s += 20;
    $t -= 20;
    $u /= 20;
    $v %= 20;

    echo $r . "</br>";
    echo $s . "</br>";
    echo $t . "</br>";
    echo $u . "</br>";
    echo $v . "</br>";

?>